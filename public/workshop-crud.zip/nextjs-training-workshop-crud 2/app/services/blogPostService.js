import axios from 'axios';

const API_URL = 'https://ait-training-rest-api.glitch.me/blog_posts';

export const getBlogPosts = async () => {
  try {
    const response = await axios.get(API_URL);
    return response.data;
  } catch (error) {
    console.error('Error fetching blog posts:', error);
    throw error;
  }
};

export const getBlogPost = async (id) => {
  try {
    const response = await axios.get(`${API_URL}/${id}`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching blog post with id ${id}:`, error);
    throw error;
  }
};

export const createBlogPost = async (blogPost) => {
  try {
    const response = await axios.post(API_URL, blogPost);
    return response.data;
  } catch (error) {
    console.error('Error creating blog post:', error);
    throw error;
  }
};

export const updateBlogPost = async (id, blogPost) => {
  try {
    const response = await axios.put(`${API_URL}/${id}`, blogPost);
    return response.data;
  } catch (error) {
    console.error(`Error updating blog post with id ${id}:`, error);
    throw error;
  }
};

export const deleteBlogPost = async (id) => {
  try {
    await axios.delete(`${API_URL}/${id}`);
    return true;
  } catch (error) {
    console.error(`Error deleting blog post with id ${id}:`, error);
    throw error;
  }
};