import Link from "next/link";

export default function BlogPostCard({ post, onDelete }) {
  return (
    <div className="card bg-base-100 shadow-xl">
      <div className="card-body">
        <h2 className="card-title">{post.title}</h2>
        {post.category && post.category.title && (
          <div className="badge badge-accent mb-2">{post.category.title}</div>
        )}
        <p className="line-clamp-3">{post.content}</p>
        <div className="card-actions justify-end mt-4">
          <Link href={`/blog-posts/${post.id}`} className="btn btn-sm btn-outline">
            View
          </Link>
          <Link href={`/blog-posts/${post.id}/edit`} className="btn btn-sm btn-outline btn-accent">
            Edit
          </Link>
          <button 
            onClick={() => onDelete(post.id)} 
            className="btn btn-sm btn-outline btn-error"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}
