import Link from "next/link";

export default function Hero() {
  return (
    <div className="hero min-h-[80vh]">
      <div className="hero-content text-center">
        <div className="max-w-md">
          <h1 className="text-5xl font-bold">Next.js CRUD Workshop</h1>
          <p className="py-6">
            Welcome to the Next.js CRUD Workshop! This application demonstrates how to build a simple CRUD (Create, Read, Update, Delete) interface for blog posts using Next.js, Tailwind CSS, and daisyUI.
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <Link href="/blog-posts" className="btn btn-primary">
              View Blog Posts
            </Link>
            <Link href="/blog-posts/new" className="btn btn-secondary">
              Create New Post
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}