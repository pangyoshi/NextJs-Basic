export default function ApiEndpoints() {
  return (
    <>
      <div className="divider my-8">API Endpoints</div>
      <div className="card bg-base-200 shadow-xl">
        <div className="card-body">
          <h2 className="card-title">Available Endpoints</h2>
          <ul className="list-disc list-inside text-left">
            <li>
              <span className="font-mono bg-base-300 px-2 py-1 rounded">
                https://ait-training-rest-api.glitch.me/blog_posts
              </span>
              <p className="mt-1">Example endpoint for blog posts CRUD operations</p>
            </li>
            <li className="mt-4">
              <span className="font-mono bg-base-300 px-2 py-1 rounded">
                https://ait-training-rest-api.glitch.me/categories
              </span>
              <p className="mt-1">Endpoint for categories to manage blog post categories</p>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
}
