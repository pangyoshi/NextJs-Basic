"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import ErrorAlert from "./ErrorAlert";
import { getCategories } from "../services/categoryService";

export default function BlogPostForm({ initialData = { title: "", content: "", category: { id: "" } }, onSubmit, isLoading }) {
  const [formData, setFormData] = useState(initialData);
  const [categories, setCategories] = useState([]);
  const [error, setError] = useState(null);
  const [loadingCategories, setLoadingCategories] = useState(true);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        setLoadingCategories(true);
        const data = await getCategories();
        setCategories(data);
      } catch (err) {
        console.error("Error fetching categories:", err);
      } finally {
        setLoadingCategories(false);
      }
    };

    fetchCategories();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "categoryId") {
      setFormData(prev => ({
        ...prev,
        category: { id: parseInt(value) }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic validation
    if (!formData.title.trim() || !formData.content.trim()) {
      setError("Title and content are required");
      return;
    }

    setError(null);
    onSubmit(formData);
  };

  return (
    <div>
      {error && <ErrorAlert message={error} />}

      <div className="card bg-base-100 shadow-xl">
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            <div className="form-control w-full">
              <label className="label">
                <span className="label-text">Title</span>
              </label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleChange}
                placeholder="Enter blog post title"
                className="input input-bordered w-full"
                disabled={isLoading}
              />
            </div>

            <div className="form-control w-full mt-4">
              <label className="label">
                <span className="label-text">Content</span>
              </label>
              <textarea
                name="content"
                value={formData.content}
                onChange={handleChange}
                placeholder="Enter blog post content"
                className="textarea textarea-bordered w-full h-64"
                disabled={isLoading}
              ></textarea>
            </div>

            <div className="form-control w-full mt-4">
              <label className="label">
                <span className="label-text">Category</span>
              </label>
              <select
                name="categoryId"
                value={formData.category?.id || ""}
                onChange={handleChange}
                className="select select-bordered w-full"
                disabled={isLoading || loadingCategories}
              >
                <option value="" disabled>Select a category</option>
                {categories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.title}
                  </option>
                ))}
              </select>
              {loadingCategories && (
                <div className="mt-2 text-sm text-gray-500">
                  <span className="loading loading-spinner loading-xs"></span>
                  <span className="ml-2">Loading categories...</span>
                </div>
              )}
            </div>

            <div className="card-actions justify-end mt-6">
              <Link href="/blog-posts" className="btn btn-ghost">
                Cancel
              </Link>
              <button 
                type="submit" 
                className="btn btn-primary"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <span className="loading loading-spinner loading-sm"></span>
                    Saving...
                  </>
                ) : "Save Post"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
