"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getBlogPost, updateBlogPost } from "../../../services/blogPostService";
import BlogPostForm from "../../../components/BlogPostForm";

export default function EditBlogPostPage({ params }) {
  const router = useRouter();
  const { id } = React.use(params);

  const [blogPost, setBlogPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchBlogPost = async () => {
      try {
        setLoading(true);
        const data = await getBlogPost(id);
        setBlogPost(data);
        setError(null);
      } catch (err) {
        setError("Failed to fetch blog post. Please try again later.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchBlogPost();
  }, [id]);

  const handleSubmit = async (formData) => {
    try {
      setSubmitting(true);
      await updateBlogPost(id, formData);
      router.push(`/blog-posts/${id}`);
    } catch (err) {
      setError("Failed to update blog post. Please try again later.");
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <span className="loading loading-spinner loading-lg text-primary"></span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="alert alert-error">
        <svg xmlns="http://www.w3.org/2000/svg" className="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
        <span>{error}</span>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Edit Blog Post</h1>
        <Link href={`/blog-posts/${id}`} className="btn btn-ghost">
          Cancel
        </Link>
      </div>

      <BlogPostForm 
        initialData={blogPost} 
        onSubmit={handleSubmit} 
        isLoading={submitting} 
      />
    </div>
  );
}
