"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createBlogPost } from "../../services/blogPostService";
import BlogPostForm from "../../components/BlogPostForm";

export default function NewBlogPostPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (formData) => {
    try {
      setLoading(true);
      await createBlogPost(formData);
      router.push("/blog-posts");
    } catch (err) {
      console.error(err);
      throw new Error("Failed to create blog post. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Create New Blog Post</h1>
        <Link href="/blog-posts" className="btn btn-ghost">
          Cancel
        </Link>
      </div>

      <BlogPostForm onSubmit={handleSubmit} isLoading={loading} />
    </div>
  );
}
