import { Geist_Mono, Inter, Sarabun } from "next/font/google";
import "./globals.css";
import Navbar from "./components/Navbar";

const sarabunFont = Sarabun({
    variable: "--font-sarabun",
    subsets: ["thai"],
    weight: ["300", "400", "500", "600", "700", "800"],
})

const interFont = Inter({
    variable: "--font-inter",
    subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: "Next.js CRUD Workshop",
  description: "Blog Posts CRUD Application for Training Workshop",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" data-theme="light" className={`${geistMono.variable} ${interFont.variable} ${sarabunFont.variable}`}>
      <body
        className={`font-sans antialiased`}
      >
        <Navbar />
        <main className="container mx-auto px-4 py-8">
          {children}
        </main>
      </body>
    </html>
  );
}
