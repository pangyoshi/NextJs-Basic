"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createCategory } from "../../services/categoryService";
import CategoryForm from "../../components/CategoryForm";

export default function NewCategoryPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (formData) => {
    try {
      setLoading(true);
      await createCategory(formData);
      router.push("/categories");
    } catch (err) {
      console.error(err);
      throw new Error("Failed to create category. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Create New Category</h1>
        <Link href="/categories" className="btn btn-ghost">
          Cancel
        </Link>
      </div>

      <CategoryForm onSubmit={handleSubmit} isLoading={loading} />
    </div>
  );
}