"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getCategory, updateCategory } from "../../../services/categoryService";
import CategoryForm from "../../../components/CategoryForm";

export default function EditCategoryPage({ params }) {
  const router = useRouter();
  const { id } = React.use(params);

  const [category, setCategory] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCategory = async () => {
      try {
        setLoading(true);
        const data = await getCategory(id);
        setCategory(data);
        setError(null);
      } catch (err) {
        setError("Failed to fetch category. Please try again later.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchCategory();
  }, [id]);

  const handleSubmit = async (formData) => {
    try {
      setSubmitting(true);
      await updateCategory(id, formData);
      router.push(`/categories/${id}`);
    } catch (err) {
      setError("Failed to update category. Please try again later.");
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <span className="loading loading-spinner loading-lg text-primary"></span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="alert alert-error">
        <svg xmlns="http://www.w3.org/2000/svg" className="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
        <span>{error}</span>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Edit Category</h1>
        <Link href={`/categories/${id}`} className="btn btn-ghost">
          Cancel
        </Link>
      </div>

      <CategoryForm 
        initialData={category} 
        onSubmit={handleSubmit} 
        isLoading={submitting} 
      />
    </div>
  );
}