"use client";

export default function CategoriesPage() {

    return (
        <div className="container mx-auto p-4">
            <h1 className="text-2xl font-bold mb-4">Let's create new Categories!</h1>
        </div>
    );

}