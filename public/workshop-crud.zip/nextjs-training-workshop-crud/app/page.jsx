import Hero from "./components/Hero";
import ApiEndpoints from "./components/ApiEndpoints";

export default function Home() {
  return (
    <div>
      <Hero />
      <div className="max-w-md mx-auto">
        <ApiEndpoints />
      </div>
    </div>
  );
}
