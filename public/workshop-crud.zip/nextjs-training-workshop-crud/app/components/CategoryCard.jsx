// import Link from "next/link";

// export default function CategoryCard({ category, onDelete }) {
//   return (
//     <div className="card bg-base-100 shadow-xl">
//       <div className="card-body">
//         <h2 className="card-title">{category.title}</h2>
//         <div className="card-actions justify-end mt-4">
//           <Link href={`/categories/${category.id}`} className="btn btn-sm btn-outline">
//             View
//           </Link>
//           <Link href={`/categories/${category.id}/edit`} className="btn btn-sm btn-outline btn-accent">
//             Edit
//           </Link>
//           <button 
//             onClick={() => onDelete(category.id)} 
//             className="btn btn-sm btn-outline btn-error"
//           >
//             Delete
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }