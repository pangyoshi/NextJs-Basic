// // app/components/CategoryForm.js
// "use client";

// import { useState } from "react";
// import Link from "next/link";
// import ErrorAlert from "./ErrorAlert";

// export default function CategoryForm({ initialData = { title: "" }, onSubmit, isLoading }) {
//   const [formData, setFormData] = useState(initialData);
//   const [error, setError] = useState(null);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData(prev => ({
//       ...prev,
//       [name]: value
//     }));
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     // Basic validation
//     if (!formData.title.trim()) {
//       setError("Title is required");
//       return;
//     }

//     setError(null);
//     onSubmit(formData);
//   };

//   return (
//     <div>
//       {error && <ErrorAlert message={error} />}

//       <div className="card bg-base-100 shadow-xl">
//         <div className="card-body">
//           <form onSubmit={handleSubmit}>
//             <div className="form-control w-full">
//               <label className="label">
//                 <span className="label-text">Title</span>
//               </label>
//               <input
//                 type="text"
//                 name="title"
//                 value={formData.title}
//                 onChange={handleChange}
//                 placeholder="Enter category title"
//                 className="input input-bordered w-full"
//                 disabled={isLoading}
//               />
//             </div>

//             <div className="card-actions justify-end mt-6">
//               <Link href="/categories" className="btn btn-ghost">
//                 Cancel
//               </Link>
//               <button 
//                 type="submit" 
//                 className="btn btn-primary"
//                 disabled={isLoading}
//               >
//                 {isLoading ? (
//                   <>
//                     <span className="loading loading-spinner loading-sm"></span>
//                     Saving...
//                   </>
//                 ) : "Save Category"}
//               </button>
//             </div>
//           </form>
//         </div>
//       </div>
//     </div>
//   );
// }